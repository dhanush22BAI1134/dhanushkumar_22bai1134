import React, { useState } from "react";
import "./Form.css";

export default function AddEventPage() {
  const [event, setEvent] = useState({
  name: "",
  date: "",
  startTime: "",
  endTime: "",
  location: "",
  description: "",
  capacity: "",
  price: "",
  status: "active",
});


  const handleChange = (e) => {
    setEvent({ ...event, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(event),
      });

      const data = await res.json();
      if (res.ok) {
        alert("Event added successfully!");
        setEvent({
            name: "",
            date: "",
            startTime: "",
            endTime: "",
            location: "",
            description: "",
            capacity: "",
            price: "",
            status: "active",
        });

      } else {
        alert(data.message || "Failed to add event.");
      }
    } catch (err) {
      console.error(err);
      alert("Server error. Try again later.");
    }
  };

  return (
    <div className="form-container">
      <h2>Add New Event</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Event Name" value={event.name} onChange={handleChange} required />
        <input type="date" name="date" value={event.date} onChange={handleChange} required />
        <input type="time" name="startTime" placeholder="Start Time" value={event.startTime} onChange={handleChange} required />
        <input type="time" name="endTime" placeholder="End Time" value={event.endTime} onChange={handleChange} required />
        <input type="text" name="location" placeholder="Location" value={event.location} onChange={handleChange} required />
        <textarea name="description" placeholder="Event Description" value={event.description} onChange={handleChange} required />
        <input type="number" name="capacity" placeholder="Capacity" value={event.capacity} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Price (₹)" value={event.price} onChange={handleChange} required />
        <select name="status" value={event.status} onChange={handleChange}>
        <option value="active">Active</option>
        <option value="cancelled">Cancelled</option>
        </select>
        <button type="submit">Add Event</button>
      </form>
    </div>
  );
}
