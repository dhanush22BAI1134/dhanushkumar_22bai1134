import React, { useEffect, useState } from "react";
import "./Form.css";

export default function DeleteEventPage() {
  const [events, setEvents] = useState([]);
  const [searchID, setSearchID] = useState("");
  const [searchName, setSearchName] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/events/all")
      .then((res) => res.json())
      .then(setEvents)
      .catch(console.error);
  }, []);

  const handleDelete = async (eventID) => {
    if (!window.confirm("Are you sure you want to delete this event?")) return;

    try {
      const res = await fetch(`http://localhost:5000/api/events/${eventID}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (res.ok) {
        alert("Event deleted successfully");
        setEvents(events.filter((ev) => ev.eventID !== eventID));
      } else {
        alert(data.message || "Delete failed");
      }
    } catch (err) {
      console.error("Delete error:", err);
      alert("Error deleting event");
    }
  };

  const filteredEvents = events.filter(
    (ev) =>
      (ev.eventID?.toLowerCase() || "").includes(searchID.toLowerCase()) &&
      (ev.name?.toLowerCase() || "").includes(searchName.toLowerCase())
  );

  return (
    <div className="form-container">
      <h2>Delete Event</h2>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search by Event ID"
          value={searchID}
          onChange={(e) => setSearchID(e.target.value)}
        />
        <input
          type="text"
          placeholder="Search by Name"
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
        />
      </div>

      <ul>
        {filteredEvents.map((event) => (
          <li
            key={event._id}
            style={{ padding: "10px", borderBottom: "1px solid #ccc" }}
          >
            {event.eventID} - {event.name}
            <button
              style={{
                marginLeft: "20px",
                padding: "5px 10px",
                background: "red",
                color: "white",
                border: "none",
                cursor: "pointer",
              }}
              onClick={() => handleDelete(event.eventID)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
