import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./EventInfoPage.css"; // Reuse the styles from EventInfoPage

export default function BookEventPage() {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
  const fetchEvents = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/events/upcoming");
      const upcomingEvents = await res.json();
      setEvents(upcomingEvents);
    } catch (err) {
      console.error("Failed to fetch events:", err);
    }
  };
  fetchEvents();
}, []);


  const handleBook = async (event) => {
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    if (!user) return navigate("/login");

    const confirm = window.confirm(`Confirm booking for: ${event.name}?`);
    if (!confirm) return;

    try {
      const res = await fetch("http://localhost:5000/api/book-event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventID: event.eventID, email: user.email, tickets: 1 })

      });

      const result = await res.json();

      if (res.ok) {
        alert("Booking successful! Downloading ticket PDF...");

        // Trigger PDF download
        const pdfRes = await fetch(`http://localhost:5000/api/download-ticket/${event.eventID}/${user.email}`);
        const blob = await pdfRes.blob();
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        link.download = `Ticket_${event.eventID}.pdf`;
        link.click();

      } else {
        alert(result.message || "Booking failed");
      }
    } catch (err) {
      console.error(err);
      alert("Error while booking.");
    }
  };

  const filteredEvents = events.filter(e =>
  (e.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
   e.eventID?.toLowerCase().includes(searchTerm.toLowerCase()))
);


  return (
    <div className="info-page-container">
      <h2>All Events</h2>

      <div style={{ display: "flex", justifyContent: "center", marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search by Event Name or ID"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ width: "60%", padding: "10px", fontSize: "16px" }}
        />
      </div>

      <div className="events-grid">
        {filteredEvents.map((event) => (
          <div className="event-card" key={event._id}>
            <h3>{event.name}</h3>
            <p><strong>Event ID:</strong> {event.eventID}</p>
            <p><strong>Date:</strong> {event.date}</p>
            <p><strong>Start Time:</strong> {event.startTime}</p>
            <p><strong>End Time:</strong> {event.endTime}</p>
            <p><strong>Location:</strong> {event.location}</p>
            <p><strong>Capacity:</strong> {event.capacity}</p>
            <p><strong>Price:</strong> ₹{event.price}</p>
            <p><strong>Status:</strong> {event.status}</p>
            <p><strong>Description:</strong> {event.description}</p>

            <button style={{ float: "right" }} onClick={() => handleBook(event)}>
              Book
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
