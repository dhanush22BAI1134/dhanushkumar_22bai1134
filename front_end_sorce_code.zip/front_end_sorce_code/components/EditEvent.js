import React, { useEffect, useState } from "react";
import "./Form.css";

export default function EditEventPage() {
  const [events, setEvents] = useState([]);
  const [searchID, setSearchID] = useState("");
  const [searchName, setSearchName] = useState("");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [updateFields, setUpdateFields] = useState({});

  useEffect(() => {
    fetch("http://localhost:5000/api/events/all")
      .then((res) => res.json())
      .then(setEvents)
      .catch(console.error);
  }, []);

  const handleFieldChange = (e) => {
    const { name, value } = e.target;
    setSelectedEvent({ ...selectedEvent, [name]: value });
  };

  const handleCheckboxToggle = (field) => {
    setUpdateFields({ ...updateFields, [field]: !updateFields[field] });
  };

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    if (!selectedEvent) return;

    const updates = {};
    for (const key in updateFields) {
      if (updateFields[key]) updates[key] = selectedEvent[key];
    }

    const res = await fetch(`http://localhost:5000/api/events/${selectedEvent.eventID}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });

    const data = await res.json();
    if (res.ok) {
      alert("Event updated successfully");
      window.location.reload();
    } else {
      alert(data.message || "Update failed");
    }
  };

  // ✅ Safely filter events
  const filteredEvents = events.filter(
    (ev) =>
      (ev.eventID?.toLowerCase() || "").includes(searchID.toLowerCase()) &&
      (ev.name?.toLowerCase() || "").includes(searchName.toLowerCase())
  );

  return (
    <div className="form-container">
      <h2>Edit Event</h2>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search by Event ID"
          value={searchID}
          onChange={(e) => setSearchID(e.target.value)}
        />
        <input
          type="text"
          placeholder="Search by Name"
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
        />
      </div>

      {selectedEvent ? (
        <form onSubmit={handleUpdateSubmit}>
          {[
            "name",
            "date",
            "startTime",
            "endTime",
            "location",
            "description",
            "capacity",
            "price",
            "status",
          ].map((field) => (
            <div key={field}>
              <label>
                <input
                  type="checkbox"
                  checked={updateFields[field] || false}
                  onChange={() => handleCheckboxToggle(field)}
                />
                Update {field}
              </label>
              {field === "description" ? (
                <textarea
                  name={field}
                  value={selectedEvent[field] || ""}
                  onChange={handleFieldChange}
                />
              ) : field === "status" ? (
                <select
                  name={field}
                  value={selectedEvent[field] || "active"}
                  onChange={handleFieldChange}
                >
                  <option value="active">Active</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              ) : (
                <input
                  type={
                    field === "date"
                      ? "date"
                      : field.includes("Time")
                      ? "time"
                      : field === "price" || field === "capacity"
                      ? "number"
                      : "text"
                  }
                  name={field}
                  value={selectedEvent[field] || ""}
                  onChange={handleFieldChange}
                />
              )}
            </div>
          ))}
          <button type="submit">Update Event</button>
        </form>
      ) : (
        <ul>
          {filteredEvents.map((event) => (
            <li
              key={event._id}
              onClick={() => {
                setSelectedEvent(event);
                setUpdateFields({});
              }}
              style={{ cursor: "pointer", padding: "8px", borderBottom: "1px solid #ccc" }}
            >
              {event.eventID} - {event.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
