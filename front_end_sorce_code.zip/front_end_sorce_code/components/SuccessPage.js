import React from "react";

export default function SuccessPage() {
  return (
    <div className="form-container">
      <h2>✅ Login Successful</h2>
      <p>Welcome! You’ve successfully logged in.</p>
    </div>
  );
}
