import React from "react";
import "./AdminDashboard.css";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>
      <div className="admin-buttons">
        <button onClick={() => navigate("/admin/add-event")}>Add Event</button>
        <button onClick={() => navigate("/admin/edit-event")}>Edit Event</button>
        <button onClick={() => navigate("/admin/delete-event")}>Delete Event</button>
        <button onClick={() => navigate("/admin/event-info")}>Event Info</button>
        <button onClick={() => navigate("/login")}>Logout</button>
      </div>
    </div>
  );
}
