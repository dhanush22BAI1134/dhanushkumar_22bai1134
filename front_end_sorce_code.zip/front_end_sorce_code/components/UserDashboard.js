import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./UserDashboard.css";

export default function UserDashboard() {
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    try {
      const userData = JSON.parse(localStorage.getItem("loggedInUser"));
      if (!userData) {
        navigate("/login");
        return;
      }
      setUser(userData);

      fetch(`http://localhost:5000/api/bookings/${userData.email}`)
        .then((res) => res.json())
        .then(setBookings)
        .catch(console.error);
    } catch (err) {
      console.error("Error reading user data:", err);
      navigate("/login");
    }
  }, [navigate]);

  const sortedBookings = bookings.sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div className="user-dashboard">
      <h2>Welcome, {user?.username}</h2>

      <button onClick={() => navigate("/user/book-event")}>📅 Book New Event</button>

      <h3>Your Recent Bookings</h3>
      <div className="booking-list">
        {sortedBookings.length === 0 ? (
          <p>No bookings found.</p>
        ) : (
          <div className="booking-grid">
            {sortedBookings.map((booking, idx) => (
              <div key={idx} className="booking-card">
                <p><strong>Event:</strong> {booking.eventName}</p>
                <p><strong>Date:</strong> {booking.date}</p>
                <p><strong>Tickets:</strong> {booking.tickets}</p>
                <p><strong>Amount Paid:</strong> ₹{booking.totalPrice}</p>
                <p><strong>Status:</strong> {booking.status}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
