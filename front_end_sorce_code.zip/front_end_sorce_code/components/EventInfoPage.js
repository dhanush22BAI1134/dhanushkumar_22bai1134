import React, { useEffect, useState } from "react";
import "./EventInfoPage.css";

export default function EventInfoPage() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/events/all")
      .then((res) => res.json())
      .then(setEvents)
      .catch((err) => console.error("Error fetching events:", err));
  }, []);

  return (
    <div className="info-page-container">
      <h2>All Events</h2>
      <div className="events-grid">
        {events.map((event) => (
          <div className="event-card" key={event._id}>
            <h3>{event.name}</h3>
            <p><strong>Event ID:</strong> {event.eventID}</p>
            <p><strong>Date:</strong> {event.date}</p>
            <p><strong>Start Time:</strong> {event.startTime}</p>
            <p><strong>End Time:</strong> {event.endTime}</p>
            <p><strong>Location:</strong> {event.location}</p>
            <p><strong>Capacity:</strong> {event.capacity}</p>
            <p><strong>Price:</strong> ₹{event.price}</p>
            <p><strong>Status:</strong> {event.status}</p>
            <p><strong>Description:</strong> {event.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

