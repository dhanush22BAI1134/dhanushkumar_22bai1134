import React, { useState } from "react";
import "./Form.css";
import { useNavigate } from "react-router-dom";

export default function SignUpForm() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const navigate = useNavigate(); // inside the component

  const handleSubmit = async (e) => {
  e.preventDefault();
  if (formData.password !== formData.confirmPassword) {
    alert("Passwords do not match");
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await res.json();

    if (res.ok) {
      navigate("/registered"); // navigate to Registered page
    } else {
      alert(data.message || "Registration failed");
    }
  } catch (err) {
    console.error(err);
    alert("Something went wrong");
  }
};

  return (
    <div className="form-container">
      <h2>Sign Up</h2>
      <p>It's free and only takes a minute</p>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="First Name" name="firstName" required onChange={handleChange} />
        <input type="text" placeholder="Last Name" name="lastName" required onChange={handleChange} />
        <input type="email" placeholder="Email" name="email" required onChange={handleChange} />
        <input type="number" placeholder="Mobile No." name="mobile" required onChange={handleChange} />
        <input type="password" placeholder="Password" name="password" required onChange={handleChange} />
        <input type="password" placeholder="Confirm Password" name="confirmPassword" required onChange={handleChange} />
        <button type="submit">Submit</button>
      </form>
      <p>By clicking Sign Up, you agree to our <a href="#">Terms and Condition</a> and <a href="#">Policy Privacy</a>.</p>
      <p>Already have an account? <a href="/login">Login here</a></p>
    </div>
  );
}
