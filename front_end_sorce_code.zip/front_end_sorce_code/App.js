import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginForm from "./components/LoginForm";
import SignUpForm from "./components/SignUpForm";
import AdminLoginForm from "./components/AdminLoginForm";
import AdminDashboard from "./components/AdminDashboard";
import AddEventPage from "./components/AddEventPage";
import EditEventPage from "./components/EditEvent";
import DeleteEventPage from "./components/DeleteEvent";
import EventInfoPage from "./components/EventInfoPage";
import UserDashboard from "./components/UserDashboard";
import BookEventPage from "./components/BookEventPage";



function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/user/:email" element={<UserDashboard />} />
        <Route path="/user/book-event" element={<BookEventPage />} />
        <Route path="/admin-login" element={<AdminLoginForm />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/admin/add-event" element={<AddEventPage />} />
        <Route path="/admin/edit-event" element={<EditEventPage />} />
        <Route path="/admin/delete-event" element={<DeleteEventPage />} />
        <Route path="/admin/event-info" element={<EventInfoPage />} />
        <Route path="/signup" element={<SignUpForm />} />
        

      </Routes>
    </Router>
  );
}

export default App;
