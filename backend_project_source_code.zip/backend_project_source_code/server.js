const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const cors = require("cors");
const path = require("path");
const PDFDocument = require("pdfkit");

const app = express();
const PORT = 5000;

// MongoDB Connection
mongoose.connect("mongodb://localhost:27017/EventbookingDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB connection error", err));

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Models and Schemas
const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: { type: String, unique: true },
  mobile: String,
  password: String,
  createdAt: { type: Date, default: Date.now }
});
const User = mongoose.model("User", userSchema);

const adminSchema = new mongoose.Schema({
  email: String,
  password: String,
  name: String
});
const Admin = mongoose.model("Admin", adminSchema);

const counterSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  seq: { type: Number, default: 0 }
});
const Counter = mongoose.model("Counter", counterSchema);

const eventSchema = new mongoose.Schema({
  eventID: { type: String, unique: true },
  name: String,
  date: String,
  startTime: String,
  endTime: String,
  location: String,
  description: String,
  capacity: Number,
  price: Number,
  status: { type: String, default: "active" },
  createdAt: { type: Date, default: Date.now }
});
const Event = mongoose.model("Event", eventSchema);

const bookingSchema = new mongoose.Schema({
  name: String, // Added name
  eventName: String,
  eventID: String,
  email: String,
  date: String,
  tickets: Number,
  totalPrice: Number,
  status: String,
  createdAt: { type: Date, default: Date.now }
});
const Booking = mongoose.model("Booking", bookingSchema);

// Auto Increment Helper
async function getNextEventID() {
  const counter = await Counter.findOneAndUpdate(
    { name: "eventID" },
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );
  return `EVT${counter.seq.toString().padStart(3, '0')}`;
}

// Routes

// User Signup
app.post("/api/signup", async (req, res) => {
  const { firstName, lastName, email, mobile, password } = req.body;

  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ firstName, lastName, email, mobile, password: hashedPassword });

    await newUser.save();
    res.json({ message: "Registered successfully" });

  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// User Login
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: "Invalid credentials" });

    const userData = {
      username: `${user.firstName} ${user.lastName}`,
      email: user.email,
      role: user.role || "user"
    };

    res.status(200).json({ message: "Login successful", user: userData });

  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Admin Login
app.post("/api/admin-login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).json({ message: "Admin not found" });

    if (admin.password !== password) return res.status(401).json({ message: "Invalid admin password" });

    res.status(200).json({ message: "Admin login successful" });

  } catch (err) {
    console.error("Admin login error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Add Event
app.post("/api/events", async (req, res) => {
  const { name, date, startTime, endTime, location, description, capacity, price, status } = req.body;

  try {
    const eventID = await getNextEventID();

    const newEvent = new Event({ eventID, name, date, startTime, endTime, location, description, capacity, price, status });
    await newEvent.save();

    res.status(201).json({ message: "Event created successfully", eventID });

  } catch (error) {
    console.error("Error adding event:", error);
    res.status(500).json({ message: "Server error while adding event" });
  }
});

// Get All Events
app.get("/api/events/all", async (req, res) => {
  try {
    const events = await Event.find();
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Get Upcoming Events
app.get("/api/events/upcoming", async (req, res) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    const events = await Event.find({ date: { $gte: today } });
    res.json(events);
  } catch (err) {
    console.error("Fetch upcoming events error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Update Event
app.patch("/api/events/:eventID", async (req, res) => {
  try {
    const eventID = req.params.eventID;
    const updates = req.body;

    const updated = await Event.findOneAndUpdate({ eventID }, updates, { new: true });
    if (!updated) return res.status(404).json({ message: "Event not found" });

    res.json({ message: "Event updated successfully", updated });

  } catch (error) {
    console.error("Update error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Delete Event
app.delete("/api/events/:eventID", async (req, res) => {
  try {
    const { eventID } = req.params;
    const deleted = await Event.findOneAndDelete({ eventID });

    if (!deleted) return res.status(404).json({ message: "Event not found" });

    res.json({ message: "Event deleted successfully" });

  } catch (error) {
    console.error("Delete error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Book Event
app.post("/api/book-event", async (req, res) => {
  const { eventID, email, tickets } = req.body;

  try {
    const event = await Event.findOne({ eventID });
    const user = await User.findOne({ email });

    if (!event) return res.status(404).json({ message: "Event not found" });

    if (event.capacity < tickets) return res.status(400).json({ message: "Not enough capacity" });

    event.capacity = event.capacity - tickets;
    if (event.capacity <= 0) {
      return res.status(400).json({ message: "No more seats available." });
    }

    await event.save();

    const booking = new Booking({
      name: user ? `${user.firstName} ${user.lastName}` : "N/A",
      eventName: event.name,
      eventID,
      email,
      date: event.date,
      tickets,
      totalPrice: tickets * event.price,
      status: "Confirmed"
    });

    await booking.save();

    res.status(200).json({ message: "Booking successful", booking });

  } catch (err) {
    console.error("Booking error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Generate Ticket PDF
app.get("/api/download-ticket/:eventID/:email", async (req, res) => {
  const { eventID, email } = req.params;

  try {
    const event = await Event.findOne({ eventID });
    const booking = await Booking.findOne({ eventID, email });

    console.log("PDF Download - Event:", event);
    console.log("PDF Download - Booking:", booking);




    if (!event || !booking) {
      return res.status(404).json({ message: "Event or booking not found" });
    }

    const doc = new PDFDocument();
    const filename = `Ticket_${eventID}_${email}.pdf`;

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename=${filename}`);

    doc.pipe(res);

    doc.fontSize(20).text("🎫 Event Ticket", { align: "center" });
    doc.moveDown();
    doc.fontSize(14).text(`Name: ${booking.name}`);
    doc.text(`Email: ${email}`);
    doc.text(`Event Name: ${event.name}`);
    doc.text(`Event ID: ${event.eventID}`);
    doc.text(`Date: ${event.date}`);
    doc.text(`Time: ${event.startTime} - ${event.endTime}`);
    doc.text(`Location: ${event.location}`);
    doc.text(`Tickets: ${booking.tickets}`);
    doc.text(`Total Price: ₹${booking.totalPrice}`);
    doc.moveDown();
    doc.text("✅ Booking Confirmed", { align: "center" });

    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error generating ticket" });
  }
});

// Start Server
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));

app.get("/api/bookings/:email", async (req, res) => {
  try {
    const email = req.params.email;

    const bookings = await Booking.find({ email });

    // Sort by date descending
    const sortedBookings = bookings.sort((a, b) => new Date(b.date) - new Date(a.date));

    res.json(sortedBookings);
  } catch (err) {
    console.error("Error fetching bookings:", err);
    res.status(500).json({ message: "Server error" });
  }
});